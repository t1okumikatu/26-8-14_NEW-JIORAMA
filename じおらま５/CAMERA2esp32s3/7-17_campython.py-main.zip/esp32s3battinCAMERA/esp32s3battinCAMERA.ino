/*
CameraWebServer (XIAO ESP32S3 移植版)
*/

#include "esp_camera.h"
#include <WiFi.h>

//ファイルシステムエクスプローラ/コンフィグ
#include <SPIFFS.h>
#include <FS.h>

// =========================================================================
// ★ 変更点1: XIAO ESP32S3 Sense 用のカメラピン定義
// =========================================================================
#define CAMERA_MODEL_XIAO_ESP32S3 // XIAO ESP32S3 用の定義を指定
#include "camera_pins.h"

// 変更点 (オリジナル機能)
bool UpdateFlag = false;
String UpdateURL = "";

// Wi-Fiタブ用
struct WiFitype {
  char ssid[32];
  char pass[64];
  char ssid2[32];
  char pass2[64];
};
struct WiFitype wifi;

struct FixedIPtype {
  byte Flag;
  unsigned long IP;
  unsigned long MASK;
  unsigned long GATE;
};
struct FixedIPtype FixedIP;

void startCameraServer();

void setup() {
  Serial.begin(115200);
  Serial.setDebugOutput(true);
  Serial.println();

  camera_config_t config;
  config.ledc_channel = LEDC_CHANNEL_0;
  config.ledc_timer = LEDC_TIMER_0;
  config.pin_d0 = Y2_GPIO_NUM;
  config.pin_d1 = Y3_GPIO_NUM;
  config.pin_d2 = Y4_GPIO_NUM;
  config.pin_d3 = Y5_GPIO_NUM;
  config.pin_d4 = Y6_GPIO_NUM;
  config.pin_d5 = Y7_GPIO_NUM;
  config.pin_d6 = Y8_GPIO_NUM;
  config.pin_d7 = Y9_GPIO_NUM;
  config.pin_xclk = XCLK_GPIO_NUM;
  config.pin_pclk = PCLK_GPIO_NUM;
  config.pin_vsync = VSYNC_GPIO_NUM;
  config.pin_href = HREF_GPIO_NUM;
  config.pin_sscb_sda = SIOD_GPIO_NUM;
  config.pin_sscb_scl = SIOC_GPIO_NUM;
  config.pin_pwdn = PWDN_GPIO_NUM;
  config.pin_reset = RESET_GPIO_NUM;
  config.xclk_freq_hz = 20000000;
  config.pixel_format = PIXFORMAT_JPEG;

  // =========================================================================
  // ★ 変更点2: XIAO ESP32S3 の PSRAM チェックとフレームバッファ設定
  // =========================================================================
  if (psramFound()) {
    config.frame_size = FRAMESIZE_UXGA;
    config.jpeg_quality = 10;
    config.fb_count = 2;
    config.grab_mode = CAMERA_GRAB_LATEST; // ストリーミングの遅延（ラグ）を軽減する設定
  } else {
    config.frame_size = FRAMESIZE_SVGA;
    config.jpeg_quality = 12;
    config.fb_count = 1;
  }

  // camera init
  esp_err_t err = esp_camera_init(&config);
  if (err != ESP_OK) {
    Serial.printf("Camera init failed with error 0x%x", err);
    return;
  }

  sensor_t* s = esp_camera_sensor_get();
  if (s->id.PID == OV3660_PID) {
    s->set_vflip(s, 1);
    s->set_brightness(s, 1);
    s->set_saturation(s, -2);
  }
  
  // XIAO ESP32S3 (OV2640) の上下反転・鏡像設定（必要に応じて調整してください）
  s->set_vflip(s, 1);
  s->set_hmirror(s, 0);
  
  // 初期フレームサイズ
  s->set_framesize(s, FRAMESIZE_SVGA);

  // WiFi initialization
  Serial.println("SPIFFSinit");
  SPIFFS.begin(true);
  Serial.println("LoadConf");
  LoadWiFiConf();
  ReadFixedIP();
  
  WiFi.begin(wifi.ssid, wifi.pass);
  long WiFiTime = millis();
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
    if (millis() > WiFiTime + 10000) break;
  }
  if (WiFi.status() != WL_CONNECTED) {
    WiFi.mode(WIFI_AP);
    WiFi.softAP("RcatESP", "12345678");
    const IPAddress ip(192, 168, 4, 1);
    const IPAddress gateway(192, 168, 4, 1);
    const IPAddress netmask(255, 255, 255, 0);
    WiFi.softAPConfig(ip, gateway, netmask);
  }

  startCameraServer();

  Serial.print("Camera Ready! Use 'http://");
  Serial.print(WiFi.localIP());
  Serial.println("' to connect");

  // ★ 補足: ESP32-CAMのGPIO4(フラッシュLED)はXIAOには無いためコメントアウトまたは削除
  // pinMode(4, OUTPUT); 
}

void loop() {
  delay(1000);
  if (UpdateFlag) {
    OnlineUpdate();
  }
}